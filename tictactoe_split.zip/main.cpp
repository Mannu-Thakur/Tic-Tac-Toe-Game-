#include <iostream>
#include "game.h"

using namespace std;

int main() {
    while (gameOver()) {
        displayCode();
        playerTurn();
    }

    if (turn == 'x' && !draw) {
        cout << "Player2 [0] wins!! Congrats!" << endl;
    } else if (turn == '0' && !draw) {
        cout << "Player1 [x] wins! Congrats!" << endl;
    } else {
        cout << "GAME DRAWN" << endl;
    }

    return 0;
}