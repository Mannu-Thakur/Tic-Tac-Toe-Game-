#ifndef GAME_H
#define GAME_H

extern char A[3][3];
extern char turn;
extern int row, column;
extern bool draw;

void displayCode();
void playerTurn();
bool gameOver();

#endif